# CyberChari - Smart Contract Audit Platform

## Overview

CyberChari is a comprehensive smart contract audit platform that integrates with GitHub and GitLab repositories to provide automated vulnerability detection and security analysis for blockchain applications. The platform features a modern web interface built with React and TypeScript, backed by a Node.js Express server with PostgreSQL database storage.

The application enables users to connect their code repositories, parse smart contracts (Solidity and Vyper), conduct security audits, and generate detailed reports. It supports OAuth authentication through Google and Apple, making it accessible to developers and security auditors in the blockchain ecosystem.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent UI design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Design System**: Custom cyber-themed design with cyan/green color scheme and Orbitron font for branding

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL store using connect-pg-simple
- **Authentication**: Passport.js with Google OAuth and Apple OAuth strategies

### Database Design
- **Primary Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle migrations for version-controlled database changes
- **Key Tables**:
  - Users: Store user profiles and authentication data
  - Repositories: Track connected GitHub/GitLab repositories
  - Smart Contracts: Store parsed contract information
  - Audit Sessions: Manage audit processes and results
  - OAuth Accounts: Link external authentication providers

### API Architecture
- **REST API**: Express routes with TypeScript interfaces
- **Repository Integration**: Dedicated services for GitHub and GitLab API interactions
- **Contract Parsing**: Service layer for detecting and parsing Solidity/Vyper contracts
- **Authentication Middleware**: Passport-based session management with role-based access

### Security Features
- **OAuth Integration**: Secure authentication through Google and Apple
- **Session Security**: HTTP-only cookies with secure flags in production
- **Repository Validation**: API validation before connecting repositories
- **Access Token Management**: Encrypted storage for private repository access

## External Dependencies

### Cloud Services
- **Neon Database**: Serverless PostgreSQL hosting for production data storage
- **GitHub API**: Repository access and smart contract parsing
- **GitLab API**: Alternative repository provider integration

### Authentication Providers
- **Google OAuth 2.0**: Primary authentication method for user sign-in
- **Apple OAuth**: Secondary authentication option for iOS ecosystem users

### Development Tools
- **Replit**: Development environment with live reload capabilities
- **Vite**: Fast development server and optimized production builds
- **Drizzle Kit**: Database migration and schema management tools

### UI/UX Libraries
- **Radix UI**: Accessible component primitives for complex UI elements
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **Lucide React**: Modern icon library for consistent iconography
- **React Icons**: Additional icon sets including brand icons (GitHub, GitLab, Google, Apple)

### API and Data Management
- **TanStack Query**: Intelligent caching and synchronization for server state
- **Zod**: Runtime type validation for API requests and responses
- **React Hook Form**: Form handling with validation support
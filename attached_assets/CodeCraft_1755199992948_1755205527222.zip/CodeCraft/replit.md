# Smart Contract Audit Platform - replit.md

## Overview

This is a full-stack smart contract security audit platform built with modern web technologies. The application provides automated and manual security analysis capabilities for smart contracts, featuring a comprehensive workflow from contract upload through report generation and certification.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite with hot module replacement

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API structure
- **Development**: TSX for TypeScript execution in development
- **Production Build**: ESBuild for server bundling

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations
- **In-Memory Fallback**: Memory-based storage implementation for development

### Authentication and Authorization
- **User Management**: Complete registration system with admin approval workflow
- **Session Management**: Secure token-based authentication with PostgreSQL session store
- **Role-Based Access**: Three role levels (Admin, Auditor, Viewer) with granular permissions
- **Invite System**: Admin-generated invite codes for controlled organizational access
- **Security Features**: Password hashing, session expiry, and role-based route protection

## Key Components

### Database Schema
- **Contracts Table**: Stores uploaded smart contract code and metadata
- **Audits Table**: Tracks audit progress, status, and automated analysis results
- **Findings Table**: Manual and automated security findings with severity levels
- **Audit Reports Table**: Generated reports and certificates

### Core Services
- **Audit Service**: Comprehensive analysis with multiple static analysis tools
  - Aderyn: Rust-based Solidity security scanner
  - MythX: Professional symbolic execution analysis
  - Slither: Trail of Bits static analysis framework
  - Securify: ETH Zurich security verification
- **Testing Service**: Advanced testing capabilities
  - Echidna fuzzing for property-based testing
  - Unit test coverage analysis
  - Gas optimization analysis
  - Adversarial attack simulations
- **Report Service**: Generates comprehensive audit reports and recommendations
- **Auth Service**: Complete user management with role-based access control
- **Storage Layer**: Abstracted storage interface with memory and database implementations

### Frontend Components
- **Dashboard**: Overview of all audits and contracts with role-based filtering
- **Upload Contract**: File upload and contract submission interface
- **Code Reviewer**: Manual code review interface with line-by-line commenting
- **Automated Results**: Display of comprehensive static analysis results (Aderyn, MythX, Slither, Securify)
- **Analysis Summary**: Overview of all analysis phases and testing results
- **Report Viewer**: Generated report display and download functionality
- **Admin Panel**: User management, approval workflow, and invite code generation

### UI Component System
- Shadcn/ui component library with consistent design system
- Radix UI primitives for accessibility and behavior
- Custom audit-specific components for security workflows

## Data Flow

1. **Contract Upload**: Users upload smart contracts through the web interface
2. **Audit Creation**: System creates audit record and initiates automated analysis
3. **Automated Analysis**: Integration with Aderyn and MythX security tools
4. **Manual Review**: Auditors can add manual findings and comments
5. **Report Generation**: Comprehensive reports with executive summaries
6. **Certification**: Final approval and certificate generation

### API Endpoints
- `POST /api/contracts` - Upload new contracts
- `GET /api/contracts` - List all contracts
- `POST /api/audits` - Create new audit
- `GET /api/audits/:id` - Get audit details with contract
- `POST /api/audits/:id/start-automated` - Trigger automated analysis
- `POST /api/findings` - Add manual findings
- `POST /api/audits/:id/generate-report` - Generate audit report

## External Dependencies

### Security Analysis Tools
- **Aderyn**: Rust-based static analysis tool for Solidity
- **MythX**: Professional security analysis API
- Both tools integrate through the audit service layer

### UI Libraries
- **Radix UI**: Accessible component primitives
- **Lucide React**: Icon library
- **Class Variance Authority**: Component variant management
- **React Hook Form**: Form handling with validation

### Development Tools
- **Drizzle Zod**: Schema validation from database models
- **Date-fns**: Date manipulation utilities
- **Embla Carousel**: Carousel components

## Deployment Strategy

### Development Environment
- Vite development server with HMR
- TSX for TypeScript execution
- Replit-specific plugins for development experience

### Production Build
- Vite builds the frontend to `dist/public`
- ESBuild bundles the server to `dist/index.js`
- Single production command serves both frontend and backend

### Database Management
- Drizzle Kit handles schema migrations
- Environment-based database URL configuration
- Automatic migration on deployment

### Environment Configuration
- `DATABASE_URL` for PostgreSQL connection
- Development vs production environment detection
- Replit-specific environment variables

The application follows a monorepo structure with shared schema definitions and clear separation between client, server, and shared code. The architecture supports both development flexibility and production scalability while maintaining type safety throughout the stack.
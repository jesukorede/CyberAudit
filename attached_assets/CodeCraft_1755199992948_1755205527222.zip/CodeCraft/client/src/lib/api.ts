import { apiRequest } from "./queryClient";
import type { Contract, InsertContract, Audit, InsertAudit, Finding, InsertFinding } from "@shared/schema";

export const api = {
  // Contract methods
  createContract: async (data: InsertContract): Promise<Contract> => {
    const response = await apiRequest('POST', '/api/contracts', data);
    return response.json();
  },

  getContracts: async (): Promise<Contract[]> => {
    const response = await apiRequest('GET', '/api/contracts');
    return response.json();
  },

  getContract: async (id: number): Promise<Contract> => {
    const response = await apiRequest('GET', `/api/contracts/${id}`);
    return response.json();
  },

  // Audit methods
  createAudit: async (data: InsertAudit): Promise<Audit> => {
    const response = await apiRequest('POST', '/api/audits', data);
    return response.json();
  },

  getAudits: async (): Promise<Audit[]> => {
    const response = await apiRequest('GET', '/api/audits');
    return response.json();
  },

  getAudit: async (id: number): Promise<Audit & { contract: Contract }> => {
    const response = await apiRequest('GET', `/api/audits/${id}`);
    return response.json();
  },

  startAutomatedAnalysis: async (id: number): Promise<Audit> => {
    const response = await apiRequest('POST', `/api/audits/${id}/start-automated`);
    return response.json();
  },

  updateAudit: async (id: number, updates: Partial<Audit>): Promise<Audit> => {
    const response = await apiRequest('PUT', `/api/audits/${id}`, updates);
    return response.json();
  },

  // Finding methods
  createFinding: async (data: InsertFinding): Promise<Finding> => {
    const response = await apiRequest('POST', '/api/findings', data);
    return response.json();
  },

  getFindings: async (auditId: number): Promise<Finding[]> => {
    const response = await apiRequest('GET', `/api/audits/${auditId}/findings`);
    return response.json();
  },

  deleteFinding: async (id: number): Promise<void> => {
    await apiRequest('DELETE', `/api/findings/${id}`);
  },

  // Report methods
  generateReport: async (auditId: number) => {
    const response = await apiRequest('POST', `/api/audits/${auditId}/generate-report`);
    return response.json();
  },

  getReport: async (auditId: number) => {
    const response = await apiRequest('GET', `/api/audits/${auditId}/report`);
    return response.json();
  },
};

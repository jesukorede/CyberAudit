import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, FileText, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface AuditProgressProps {
  audit: {
    id: number;
    status: string;
    overallProgress: number;
  };
}

export function AuditProgress({ audit }: AuditProgressProps) {
  const steps = [
    {
      name: "Upload",
      description: "Completed",
      icon: CheckCircle,
      status: "completed"
    },
    {
      name: "Automated Scan", 
      description: audit.status === "pending" ? "Pending" : "Completed",
      icon: audit.status === "pending" ? Clock : CheckCircle,
      status: audit.status === "pending" ? "pending" : "completed"
    },
    {
      name: "Manual Review",
      description: audit.status === "manual_review" ? "In Progress" : 
                  audit.status === "completed" ? "Completed" : "Pending",
      icon: audit.status === "manual_review" ? Clock : 
            audit.status === "completed" ? CheckCircle : AlertCircle,
      status: audit.status === "manual_review" ? "in_progress" :
              audit.status === "completed" ? "completed" : "pending"
    },
    {
      name: "Report",
      description: audit.status === "completed" ? "Completed" : "Pending", 
      icon: audit.status === "completed" ? CheckCircle : FileText,
      status: audit.status === "completed" ? "completed" : "pending"
    }
  ];

  const getStepColor = (status: string) => {
    switch (status) {
      case "completed": return "text-green-600 bg-green-100";
      case "in_progress": return "text-amber-600 bg-amber-100";
      case "pending": return "text-gray-600 bg-gray-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  return (
    <div className="bg-background rounded-xl shadow-sm border border-border p-6 mb-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Audit Progress</h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">Audit ID:</span>
          <Badge variant="outline" className="font-mono">
            AUD-{audit.id.toString().padStart(3, '0')}
          </Badge>
        </div>
      </div>
      
      <div className="grid grid-cols-4 gap-4 mb-6">
        {steps.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={step.name} className="text-center">
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2",
                getStepColor(step.status)
              )}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-sm font-medium text-foreground">{step.name}</div>
              <div className="text-xs text-muted-foreground">{step.description}</div>
            </div>
          );
        })}
      </div>
      
      <div className="bg-muted rounded-lg p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-foreground">Overall Progress</span>
          <span className="text-sm font-semibold text-foreground">{audit.overallProgress}%</span>
        </div>
        <Progress value={audit.overallProgress} className="h-3" />
      </div>
    </div>
  );
}

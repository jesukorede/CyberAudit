import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { InsertContract } from "@shared/schema";

interface UploadContractProps {
  onSuccess: (contractId: number) => void;
  onCancel: () => void;
}

export function UploadContract({ onSuccess, onCancel }: UploadContractProps) {
  const [contractData, setContractData] = useState({
    name: "",
    content: "",
    language: "solidity"
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: (data: InsertContract) => api.createContract(data),
    onSuccess: (contract) => {
      toast({
        title: "Contract uploaded successfully",
        description: `${contract.name} has been uploaded and is ready for audit.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      onSuccess(contract.id);
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your contract. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setContractData(prev => ({
          ...prev,
          content,
          name: prev.name || file.name
        }));
      };
      reader.readAsText(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contractData.name.trim() || !contractData.content.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both contract name and content.",
        variant: "destructive",
      });
      return;
    }
    uploadMutation.mutate(contractData);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileCode className="w-5 h-5" />
          Upload Smart Contract
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Contract Name</Label>
            <Input
              id="name"
              placeholder="e.g., DeFiToken.sol"
              value={contractData.name}
              onChange={(e) => setContractData(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="file">Upload File</Label>
            <div className="flex items-center gap-4">
              <Input
                id="file"
                type="file"
                accept=".sol,.vy,.cairo"
                onChange={handleFileUpload}
                className="flex-1"
              />
              <Button type="button" variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Browse
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Contract Source Code</Label>
            <Textarea
              id="content"
              placeholder="Paste your smart contract source code here..."
              value={contractData.content}
              onChange={(e) => setContractData(prev => ({ ...prev, content: e.target.value }))}
              rows={12}
              className="font-mono text-sm"
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={uploadMutation.isPending}
              className="min-w-[120px]"
            >
              {uploadMutation.isPending ? "Uploading..." : "Upload & Start Audit"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

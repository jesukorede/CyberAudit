import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Download, Tag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { Audit, Contract, Finding } from "@shared/schema";

interface ReportViewerProps {
  audit: Audit & { contract: Contract };
  findings: Finding[];
}

export function ReportViewer({ audit, findings }: ReportViewerProps) {
  const { toast } = useToast();

  const generateReportMutation = useMutation({
    mutationFn: () => api.generateReport(audit.id),
    onSuccess: () => {
      toast({
        title: "Report generated",
        description: "Your audit report has been generated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateSummary = () => {
    return {
      total: findings.length,
      critical: findings.filter(f => f.severity === 'Critical').length,
      high: findings.filter(f => f.severity === 'High').length,
      medium: findings.filter(f => f.severity === 'Medium').length,
      low: findings.filter(f => f.severity === 'Low').length,
    };
  };

  const summary = calculateSummary();
  const criticalFindings = findings.filter(f => f.severity === 'Critical');

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-red-500";
      case "High": return "bg-orange-500";
      case "Medium": return "bg-amber-500";
      case "Low": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-foreground mb-2">Smart Contract Audit Report</h1>
              <div className="text-muted-foreground space-y-1">
                <p>Contract: <span className="font-semibold">{audit.contract.name}</span></p>
                <p>Audit Date: <span>{new Date(audit.createdAt).toLocaleDateString()}</span></p>
                <p>Audit ID: <Badge variant="outline" className="font-mono">AUD-{audit.id.toString().padStart(3, '0')}</Badge></p>
              </div>
            </div>
            
            <div className="grid grid-cols-4 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600 mb-2">{summary.critical}</div>
                <div className="text-sm font-medium text-muted-foreground">Critical</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">{summary.high}</div>
                <div className="text-sm font-medium text-muted-foreground">High</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-amber-600 mb-2">{summary.medium}</div>
                <div className="text-sm font-medium text-muted-foreground">Medium</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">{summary.low}</div>
                <div className="text-sm font-medium text-muted-foreground">Low</div>
              </div>
            </div>
            
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-foreground mb-4">Executive Summary</h2>
              <div className="bg-muted rounded-lg p-6">
                <p className="text-foreground leading-relaxed">
                  {summary.critical > 0 ? (
                    `The smart contract audit has identified ${summary.critical} critical security vulnerabilities that require immediate attention. The contract contains issues that could lead to significant financial losses and should not be deployed until all critical findings are resolved.`
                  ) : summary.high > 0 ? (
                    `The smart contract audit has identified ${summary.high} high-severity security issues that require attention before deployment. While not immediately critical, these issues pose significant security risks.`
                  ) : summary.medium > 0 ? (
                    `The smart contract audit has identified ${summary.medium} medium-severity issues that should be addressed to improve the contract's security posture.`
                  ) : (
                    `The smart contract audit has been completed successfully with no critical or high-severity issues identified. The contract appears to follow security best practices.`
                  )}
                </p>
              </div>
            </div>
            
            {criticalFindings.length > 0 && (
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-foreground mb-4">Critical Findings</h2>
                <div className="space-y-4">
                  {criticalFindings.map((finding, index) => (
                    <div key={finding.id} className="border border-red-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium text-foreground">CF-{(index + 1).toString().padStart(3, '0')}: {finding.type}</h3>
                        <Badge className="bg-red-500 text-white text-xs">Critical</Badge>
                      </div>
                      <p className="text-foreground mb-2">{finding.comment}</p>
                      <div className="text-sm text-muted-foreground">
                        <strong>Location:</strong> Line {finding.lineNumber}<br/>
                        <strong>Type:</strong> {finding.type}<br/>
                        <strong>Impact:</strong> High security risk
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mb-8">
              <h2 className="text-xl font-semibold text-foreground mb-4">All Findings</h2>
              {findings.length === 0 ? (
                <p className="text-muted-foreground">No findings identified during the audit.</p>
              ) : (
                <div className="space-y-3">
                  {findings.map((finding, index) => (
                    <div key={finding.id} className="border border-border rounded-lg p-3">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <Badge className={`text-white text-xs ${getSeverityColor(finding.severity)}`}>
                            {finding.severity}
                          </Badge>
                          <span className="font-medium text-foreground">{finding.type}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">Line {finding.lineNumber}</span>
                      </div>
                      <p className="text-sm text-foreground">{finding.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <Separator className="my-8" />
            
            <div className="flex justify-between items-center">
              <div className="text-sm text-muted-foreground">
                Generated on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
              </div>
              <div className="space-x-3">
                <Button 
                  variant="outline"
                  onClick={() => generateReportMutation.mutate()}
                  disabled={generateReportMutation.isPending}
                >
                  <Download className="w-4 h-4 mr-2" />
                  {generateReportMutation.isPending ? "Generating..." : "Download PDF"}
                </Button>
                {summary.critical === 0 && summary.high === 0 && (
                  <Button 
                    onClick={() => generateReportMutation.mutate()}
                    disabled={generateReportMutation.isPending}
                  >
                    <Tag className="w-4 h-4 mr-2" />
                    Generate Tag
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

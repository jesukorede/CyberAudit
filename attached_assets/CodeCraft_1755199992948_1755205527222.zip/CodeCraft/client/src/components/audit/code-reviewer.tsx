import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Expand, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import type { Finding, InsertFinding } from "@shared/schema";

interface CodeReviewerProps {
  contractId: number;
  auditId: number;
  contractContent: string;
  contractName: string;
  findings: Finding[];
}

export function CodeReviewer({ contractId, auditId, contractContent, contractName, findings }: CodeReviewerProps) {
  const [selectedLine, setSelectedLine] = useState<number | null>(null);
  const [findingForm, setFindingForm] = useState({
    severity: "Medium" as const,
    type: "Logic Error",
    comment: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addFindingMutation = useMutation({
    mutationFn: (data: InsertFinding) => api.createFinding(data),
    onSuccess: () => {
      toast({
        title: "Finding added",
        description: "Your finding has been added to the audit.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/audits", auditId, "findings"] });
      setFindingForm({ severity: "Medium", type: "Logic Error", comment: "" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add finding. Please try again.",
        variant: "destructive",
      });
    },
  });

  const codeLines = contractContent.split('\n');

  const handleAddFinding = () => {
    if (!selectedLine || !findingForm.comment.trim()) {
      toast({
        title: "Missing information",
        description: "Please select a line and add a comment.",
        variant: "destructive",
      });
      return;
    }

    addFindingMutation.mutate({
      auditId,
      lineNumber: selectedLine,
      severity: findingForm.severity,
      type: findingForm.type,
      comment: findingForm.comment,
      source: "manual"
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-red-500";
      case "High": return "bg-orange-500";
      case "Medium": return "bg-amber-500";
      case "Low": return "bg-green-500";
      case "Info": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const getLineFinding = (lineNumber: number) => {
    return findings.find(f => f.lineNumber === lineNumber);
  };

  return (
    <div className="flex h-[600px]">
      {/* Code Editor Panel */}
      <div className="flex-1 border-r border-border">
        <div className="p-4 border-b border-border bg-muted">
          <div className="flex items-center justify-between">
            <h3 className="font-medium text-foreground">{contractName}</h3>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Lines: {codeLines.length}</span>
              <Button variant="outline" size="sm">
                <Expand className="w-4 h-4 mr-1" />
                Fullscreen
              </Button>
            </div>
          </div>
        </div>
        
        <div className="h-full overflow-auto bg-gray-900 text-gray-100 font-mono text-sm">
          <div className="flex">
            <div className="bg-gray-800 text-gray-400 px-4 py-2 text-right border-r border-gray-700 min-w-[60px]">
              {codeLines.map((_, index) => {
                const lineNumber = index + 1;
                const finding = getLineFinding(lineNumber);
                return (
                  <div
                    key={lineNumber}
                    className={cn(
                      "leading-6 cursor-pointer hover:bg-gray-700 px-1 relative",
                      selectedLine === lineNumber && "bg-blue-600",
                      finding && getSeverityColor(finding.severity)
                    )}
                    onClick={() => setSelectedLine(lineNumber)}
                  >
                    {lineNumber}
                  </div>
                );
              })}
            </div>
            <div className="flex-1 p-4 overflow-auto">
              <pre className="text-gray-100 leading-6">
                <code>
                  {codeLines.map((line, index) => {
                    const lineNumber = index + 1;
                    const finding = getLineFinding(lineNumber);
                    return (
                      <div
                        key={lineNumber}
                        className={cn(
                          "leading-6",
                          finding && "bg-red-900/20",
                          selectedLine === lineNumber && "bg-blue-900/20"
                        )}
                      >
                        {line}
                      </div>
                    );
                  })}
                </code>
              </pre>
            </div>
          </div>
        </div>
      </div>

      {/* Findings Panel */}
      <div className="w-96 bg-muted">
        <div className="p-4 border-b border-border">
          <h3 className="font-medium text-foreground">Add Finding</h3>
          {selectedLine && (
            <div className="text-sm text-muted-foreground">Line {selectedLine} selected</div>
          )}
        </div>
        
        <div className="p-4 space-y-4">
          <div>
            <Label>Severity</Label>
            <Select
              value={findingForm.severity}
              onValueChange={(value: any) => setFindingForm(prev => ({ ...prev, severity: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
                <SelectItem value="Info">Info</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Finding Type</Label>
            <Select
              value={findingForm.type}
              onValueChange={(value) => setFindingForm(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Access Control">Access Control</SelectItem>
                <SelectItem value="Arithmetic Issues">Arithmetic Issues</SelectItem>
                <SelectItem value="Reentrancy">Reentrancy</SelectItem>
                <SelectItem value="Gas Optimization">Gas Optimization</SelectItem>
                <SelectItem value="Logic Error">Logic Error</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Comment</Label>
            <Textarea
              value={findingForm.comment}
              onChange={(e) => setFindingForm(prev => ({ ...prev, comment: e.target.value }))}
              rows={4}
              placeholder="Describe the security issue or suggestion..."
            />
          </div>
          
          <Button 
            onClick={handleAddFinding}
            disabled={!selectedLine || !findingForm.comment.trim() || addFindingMutation.isPending}
            className="w-full"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Finding
          </Button>
        </div>
        
        <div className="border-t border-border p-4">
          <h4 className="font-medium text-foreground mb-3">Current Findings</h4>
          <div className="space-y-2 max-h-64 overflow-auto">
            {findings.length === 0 ? (
              <p className="text-sm text-muted-foreground">No findings yet</p>
            ) : (
              findings.map((finding) => (
                <Card key={finding.id} className="p-3">
                  <div className="flex items-start justify-between mb-2">
                    <Badge className={cn("text-white text-xs", getSeverityColor(finding.severity))}>
                      {finding.severity}
                    </Badge>
                    <span className="text-xs text-muted-foreground">Line {finding.lineNumber}</span>
                  </div>
                  <p className="text-sm text-foreground">{finding.comment}</p>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

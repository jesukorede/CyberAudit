import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CheckCircle } from "lucide-react";
import type { Audit } from "@shared/schema";

interface AutomatedResultsProps {
  audit: Audit;
}

export function AutomatedResults({ audit }: AutomatedResultsProps) {
  const aderynReport = audit.aderynReport as any;
  const mythxReport = audit.mythxReport as any;

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Critical": return "bg-red-500";
      case "High": return "bg-orange-500";
      case "Medium": return "bg-amber-500";
      case "Low": return "bg-green-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-2 gap-6">
        {/* Aderyn Analysis */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Aderyn Analysis</CardTitle>
              <Badge variant="outline" className="bg-green-100 text-green-700">
                <CheckCircle className="w-3 h-3 mr-1" />
                Completed
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {aderynReport?.summary ? (
              <>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Critical Issues:</span>
                    <span className="font-semibold text-red-600">{aderynReport.summary.criticalCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">High Issues:</span>
                    <span className="font-semibold text-orange-600">{aderynReport.summary.highCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Medium Issues:</span>
                    <span className="font-semibold text-amber-600">{aderynReport.summary.mediumCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Low Issues:</span>
                    <span className="font-semibold text-green-600">{aderynReport.summary.lowCount}</span>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="font-medium text-foreground mb-2">Recent Findings</h4>
                  <div className="space-y-2">
                    {aderynReport.issues?.slice(0, 2).map((issue: any, index: number) => (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        <span className={`w-2 h-2 rounded-full ${getSeverityColor(issue.severity)}`}></span>
                        <span className="text-foreground">{issue.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <p className="text-muted-foreground">No analysis results available</p>
            )}
          </CardContent>
        </Card>
        
        {/* MythX Analysis */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">MythX Analysis</CardTitle>
              <Badge variant="outline" className="bg-green-100 text-green-700">
                <CheckCircle className="w-3 h-3 mr-1" />
                Completed
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {mythxReport?.summary ? (
              <>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Critical Issues:</span>
                    <span className="font-semibold text-red-600">{mythxReport.summary.criticalCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">High Issues:</span>
                    <span className="font-semibold text-orange-600">{mythxReport.summary.highCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Medium Issues:</span>
                    <span className="font-semibold text-amber-600">{mythxReport.summary.mediumCount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Low Issues:</span>
                    <span className="font-semibold text-green-600">{mythxReport.summary.lowCount}</span>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="font-medium text-foreground mb-2">Recent Findings</h4>
                  <div className="space-y-2">
                    {mythxReport.issues?.slice(0, 2).map((issue: any, index: number) => (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        <span className={`w-2 h-2 rounded-full ${getSeverityColor(issue.severity)}`}></span>
                        <span className="text-foreground">{issue.title}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <p className="text-muted-foreground">No analysis results available</p>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Detailed Findings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Detailed Findings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {aderynReport?.issues?.map((issue: any, index: number) => (
              <div key={`aderyn-${index}`} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Badge className={`text-white text-xs ${getSeverityColor(issue.severity)}`}>
                      {issue.severity}
                    </Badge>
                    <h4 className="font-medium text-foreground">{issue.title}</h4>
                  </div>
                  <span className="text-sm text-muted-foreground">Aderyn</span>
                </div>
                <p className="text-foreground mb-3">{issue.description}</p>
                <div className="text-sm text-muted-foreground">
                  <span className="font-medium">Location:</span> {issue.location}
                </div>
              </div>
            ))}
            
            {mythxReport?.issues?.map((issue: any, index: number) => (
              <div key={`mythx-${index}`} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Badge className={`text-white text-xs ${getSeverityColor(issue.severity)}`}>
                      {issue.severity}
                    </Badge>
                    <h4 className="font-medium text-foreground">{issue.title}</h4>
                  </div>
                  <span className="text-sm text-muted-foreground">MythX</span>
                </div>
                <p className="text-foreground mb-3">{issue.description}</p>
                {issue.sourceMap && (
                  <div className="text-sm text-muted-foreground">
                    <span className="font-medium">Source Map:</span> {issue.sourceMap}
                  </div>
                )}
              </div>
            ))}
            
            {(!aderynReport?.issues?.length && !mythxReport?.issues?.length) && (
              <p className="text-muted-foreground text-center py-8">No automated findings available</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

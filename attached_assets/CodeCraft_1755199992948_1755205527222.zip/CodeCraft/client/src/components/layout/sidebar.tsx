import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  FileCode, 
  Bot, 
  FileText, 
  Tag,
  Clock
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface SidebarProps {
  currentAudit?: {
    id: number;
    contractName: string;
    status: string;
    progress: number;
    createdAt: string;
  };
}

export function Sidebar({ currentAudit }: SidebarProps) {
  const [location] = useLocation();

  const navigation = [
    { name: 'Dashboard', href: '/', icon: LayoutDashboard },
    { name: 'Code Review', href: '/review', icon: FileCode },
    { name: 'Automated Analysis', href: '/automated', icon: Bot },
    { name: 'Reports', href: '/reports', icon: FileText },
    { name: 'Certificates', href: '/certificates', icon: Tag },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'manual_review': return 'bg-amber-500';
      case 'automated': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'manual_review': return 'In Review';
      case 'automated': return 'Analyzing';
      case 'failed': return 'Failed';
      default: return 'Pending';
    }
  };

  return (
    <aside className="w-64 bg-background shadow-sm border-r border-border">
      <nav className="p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <item.icon className="w-4 h-4" />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>
      
      {currentAudit && (
        <div className="p-4 border-t border-border mt-8">
          <h3 className="text-sm font-semibold text-foreground mb-3">Current Audit</h3>
          <div className="bg-muted rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground truncate">
                {currentAudit.contractName}
              </span>
              <Badge 
                variant="secondary" 
                className={cn("text-white text-xs", getStatusColor(currentAudit.status))}
              >
                {getStatusText(currentAudit.status)}
              </Badge>
            </div>
            <div className="flex items-center text-xs text-muted-foreground mb-2">
              <Clock className="w-3 h-3 mr-1" />
              {currentAudit.createdAt}
            </div>
            <Progress value={currentAudit.progress} className="h-2 mb-1" />
            <div className="text-xs text-muted-foreground">
              {currentAudit.progress}% Complete
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}

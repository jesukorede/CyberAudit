import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Shield, Plus } from "lucide-react";
import { Link } from "wouter";

interface AppHeaderProps {
  onNewAudit: () => void;
}

export function AppHeader({ onNewAudit }: AppHeaderProps) {
  return (
    <header className="bg-background shadow-sm border-b border-border">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <Shield className="text-primary text-2xl" />
              <h1 className="font-bold text-foreground text-[23px] ml-[4px] mr-[4px]">CyberChari SecureAudit </h1>
            </Link>
            <span className="text-sm text-muted-foreground">Smart Contract Security Platform</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button onClick={onNewAudit} className="flex items-center space-x-2">
              <Plus className="w-4 h-4" />
              <span>New Audit</span>
            </Button>
            <div className="flex items-center space-x-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40" />
                <AvatarFallback>JA</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium text-foreground">John Auditor</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

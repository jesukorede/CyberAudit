import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppHeader } from "@/components/layout/app-header";
import { Sidebar } from "@/components/layout/sidebar";
import Dashboard from "@/pages/dashboard";
import AuditDetails from "@/pages/audit-details";
import { useState } from "react";
import { UploadContract } from "@/components/audit/upload-contract";
import { api } from "./lib/api";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/audit/:id" component={AuditDetails} />
      <Route path="/review" component={() => <div className="p-6">Code Review Page</div>} />
      <Route path="/automated" component={() => <div className="p-6">Automated Analysis Page</div>} />
      <Route path="/reports" component={() => <div className="p-6">Reports Page</div>} />
      <Route path="/certificates" component={() => <div className="p-6">Certificates Page</div>} />
    </Switch>
  );
}

function App() {
  const [showUploadModal, setShowUploadModal] = useState(false);

  const handleNewAudit = () => {
    setShowUploadModal(true);
  };

  const handleContractUploaded = async (contractId: number) => {
    // Create a new audit for the uploaded contract
    await api.createAudit({ contractId, status: "pending", overallProgress: 0 });
    setShowUploadModal(false);
    // Optionally redirect to the new audit
    window.location.href = '/';
  };

  // Mock current audit data - in a real app this would come from state/context
  const currentAudit = {
    id: 1,
    contractName: "DeFiToken.sol",
    status: "manual_review",
    progress: 60,
    createdAt: "2 hours ago"
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background">
          <AppHeader onNewAudit={handleNewAudit} />
          
          <div className="flex">
            <Sidebar currentAudit={currentAudit} />
            <main className="flex-1">
              <Router />
            </main>
          </div>

          {showUploadModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-6 z-50">
              <div className="bg-background rounded-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
                <UploadContract
                  onSuccess={handleContractUploaded}
                  onCancel={() => setShowUploadModal(false)}
                />
              </div>
            </div>
          )}
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

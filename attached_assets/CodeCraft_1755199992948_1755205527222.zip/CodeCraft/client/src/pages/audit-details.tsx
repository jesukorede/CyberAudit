import { useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { AuditProgress } from "@/components/audit/audit-progress";
import { CodeReviewer } from "@/components/audit/code-reviewer";
import { AutomatedResults } from "@/components/audit/automated-results";
import { ReportViewer } from "@/components/audit/report-viewer";
import { Code, Bot, AlertTriangle, FileText, Save, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

export default function AuditDetails() {
  const { id } = useParams();
  const auditId = parseInt(id || "0");
  const [activeTab, setActiveTab] = useState("review");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: audit, isLoading: auditLoading } = useQuery({
    queryKey: ["/api/audits", auditId],
    queryFn: () => api.getAudit(auditId),
    enabled: !!auditId,
  });

  const { data: findings = [], isLoading: findingsLoading } = useQuery({
    queryKey: ["/api/audits", auditId, "findings"],
    queryFn: () => api.getFindings(auditId),
    enabled: !!auditId,
  });

  const startAutomatedMutation = useMutation({
    mutationFn: () => api.startAutomatedAnalysis(auditId),
    onSuccess: () => {
      toast({
        title: "Automated analysis started",
        description: "The automated security analysis has been initiated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/audits", auditId] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start automated analysis.",
        variant: "destructive",
      });
    },
  });

  const updateAuditMutation = useMutation({
    mutationFn: (updates: any) => api.updateAudit(auditId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/audits", auditId] });
    },
  });

  const handleSubmitReview = () => {
    updateAuditMutation.mutate({
      status: "manual_review",
      overallProgress: 75
    });
    toast({
      title: "Review submitted",
      description: "Your manual review has been submitted successfully.",
    });
  };

  const handleSaveProgress = () => {
    toast({
      title: "Progress saved",
      description: "Your progress has been saved.",
    });
  };

  if (auditLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading audit details...</p>
        </div>
      </div>
    );
  }

  if (!audit) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-2">Audit not found</h2>
          <p className="text-muted-foreground">The requested audit could not be found.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <AuditProgress audit={audit} />
      
      <div className="bg-background rounded-xl shadow-sm border border-border overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="border-b border-border">
            <TabsList className="w-full justify-start bg-transparent p-0 h-auto">
              <TabsTrigger 
                value="review" 
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-4"
              >
                <Code className="w-4 h-4" />
                Code Review
              </TabsTrigger>
              <TabsTrigger 
                value="automated"
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-4"
              >
                <Bot className="w-4 h-4" />
                Automated Results
              </TabsTrigger>
              <TabsTrigger 
                value="findings"
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-4"
              >
                <AlertTriangle className="w-4 h-4" />
                Findings ({findings.length})
              </TabsTrigger>
              <TabsTrigger 
                value="report"
                className="flex items-center gap-2 data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-6 py-4"
              >
                <FileText className="w-4 h-4" />
                Report
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="review" className="p-0">
            <CodeReviewer
              contractId={audit.contractId}
              auditId={audit.id}
              contractContent={audit.contract.content}
              contractName={audit.contract.name}
              findings={findings}
            />
          </TabsContent>

          <TabsContent value="automated" className="p-0">
            <div className="p-6">
              {audit.status === "pending" ? (
                <div className="text-center py-12">
                  <Bot className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-foreground mb-2">
                    Automated Analysis Not Started
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Start the automated security analysis to see results from Aderyn and MythX.
                  </p>
                  <Button 
                    onClick={() => startAutomatedMutation.mutate()}
                    disabled={startAutomatedMutation.isPending}
                  >
                    {startAutomatedMutation.isPending ? "Starting..." : "Start Automated Analysis"}
                  </Button>
                </div>
              ) : (
                <AutomatedResults audit={audit} />
              )}
            </div>
          </TabsContent>

          <TabsContent value="findings" className="p-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-foreground">All Findings</h3>
              {findingsLoading ? (
                <div className="text-center py-8 text-muted-foreground">Loading findings...</div>
              ) : findings.length === 0 ? (
                <div className="text-center py-8">
                  <AlertTriangle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h4 className="text-lg font-medium text-foreground mb-2">No findings yet</h4>
                  <p className="text-muted-foreground">
                    Start by running automated analysis or adding manual findings in the code review tab.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {findings.map((finding) => (
                    <div key={finding.id} className="border border-border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-1 rounded text-xs font-medium text-white ${
                            finding.severity === 'Critical' ? 'bg-red-500' :
                            finding.severity === 'High' ? 'bg-orange-500' :
                            finding.severity === 'Medium' ? 'bg-amber-500' :
                            finding.severity === 'Low' ? 'bg-green-500' : 'bg-blue-500'
                          }`}>
                            {finding.severity}
                          </span>
                          <span className="font-medium text-foreground">{finding.type}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>Line {finding.lineNumber}</span>
                          <span>•</span>
                          <span className="capitalize">{finding.source}</span>
                        </div>
                      </div>
                      <p className="text-foreground">{finding.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="report" className="p-0">
            <ReportViewer audit={audit} findings={findings} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex space-x-3">
        <Button 
          onClick={handleSubmitReview}
          disabled={updateAuditMutation.isPending}
          className="shadow-lg"
        >
          <Check className="w-4 h-4 mr-2" />
          Submit Review
        </Button>
        <Button 
          variant="secondary"
          onClick={handleSaveProgress}
          className="shadow-lg"
        >
          <Save className="w-4 h-4 mr-2" />
          Save Progress
        </Button>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { UploadContract } from "@/components/audit/upload-contract";
import { Plus, FileCode, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { api } from "@/lib/api";
import { Link } from "wouter";

export default function Dashboard() {
  const [showUpload, setShowUpload] = useState(false);

  const { data: audits = [], isLoading: auditsLoading } = useQuery({
    queryKey: ["/api/audits"],
    queryFn: () => api.getAudits(),
  });

  const { data: contracts = [], isLoading: contractsLoading } = useQuery({
    queryKey: ["/api/contracts"],
    queryFn: () => api.getContracts(),
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="w-4 h-4 text-green-600" />;
      case "manual_review": return <Clock className="w-4 h-4 text-amber-600" />;
      case "failed": return <AlertCircle className="w-4 h-4 text-red-600" />;
      default: return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed": return "Completed";
      case "manual_review": return "In Review";
      case "automated": return "Analyzing";
      case "failed": return "Failed";
      default: return "Pending";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "manual_review": return "bg-amber-100 text-amber-800";
      case "automated": return "bg-blue-100 text-blue-800";
      case "failed": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handleContractUploaded = async (contractId: number) => {
    // Create a new audit for the uploaded contract
    await api.createAudit({ contractId, status: "pending", overallProgress: 0 });
    setShowUpload(false);
  };

  if (showUpload) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <UploadContract
          onSuccess={handleContractUploaded}
          onCancel={() => setShowUpload(false)}
        />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Audit Dashboard</h1>
          <p className="text-muted-foreground">Monitor and manage your smart contract audits</p>
        </div>
        <Button onClick={() => setShowUpload(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Audit
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Audits</CardTitle>
            <FileCode className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{audits.length}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {audits.filter(a => a.status === "manual_review" || a.status === "automated").length}
            </div>
            <p className="text-xs text-muted-foreground">Active audits</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {audits.filter(a => a.status === "completed").length}
            </div>
            <p className="text-xs text-muted-foreground">Successful audits</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contracts</CardTitle>
            <FileCode className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{contracts.length}</div>
            <p className="text-xs text-muted-foreground">Total uploaded</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Audits */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Audits</CardTitle>
        </CardHeader>
        <CardContent>
          {auditsLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading audits...</div>
          ) : audits.length === 0 ? (
            <div className="text-center py-8">
              <FileCode className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">No audits yet</h3>
              <p className="text-muted-foreground mb-4">Get started by uploading your first smart contract</p>
              <Button onClick={() => setShowUpload(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Upload Contract
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {audits.slice(0, 5).map((audit) => (
                <div key={audit.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(audit.status)}
                    <div>
                      <h4 className="font-medium text-foreground">
                        Contract Audit #{audit.id.toString().padStart(3, '0')}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        Created {new Date(audit.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Badge className={getStatusColor(audit.status)}>
                      {getStatusText(audit.status)}
                    </Badge>
                    <div className="text-sm text-muted-foreground">
                      {audit.overallProgress}%
                    </div>
                    <Link href={`/audit/${audit.id}`}>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

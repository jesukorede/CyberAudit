import axios from 'axios';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { testingService, type FuzzingResult, type StressTestResult, type AttackSimulationResult } from './testing-service';

interface AderynIssue {
  title: string;
  severity: string;
  location: string;
  description: string;
}

interface MythXIssue {
  title: string;
  severity: string;
  description: string;
  sourceMap: string;
}

interface SlitherIssue {
  check: string;
  confidence: string;
  impact: string;
  description: string;
  elements: Array<{
    name: string;
    source_mapping: {
      start: number;
      length: number;
      filename_relative: string;
      lines: number[];
    };
  }>;
}

interface SecurifyIssue {
  severity: string;
  title: string;
  description: string;
  line: number;
  column: number;
}

interface CoverageReport {
  totalLines: number;
  coveredLines: number;
  coveragePercentage: number;
  uncoveredFunctions: string[];
  branchCoverage: number;
}

interface GasOptimizationReport {
  totalGasUsed: number;
  optimizationSuggestions: Array<{
    location: string;
    description: string;
    potentialSaving: number;
    severity: 'High' | 'Medium' | 'Low';
  }>;
  expensiveFunctions: Array<{
    name: string;
    gasUsage: number;
    optimizationHint: string;
  }>;
}

export interface AderynReport {
  issues: AderynIssue[];
  summary: {
    totalIssues: number;
    criticalCount: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
  };
}

export interface MythXReport {
  issues: MythXIssue[];
  summary: {
    totalIssues: number;
    criticalCount: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
  };
}

export interface SlitherReport {
  issues: SlitherIssue[];
  summary: {
    totalIssues: number;
    criticalCount: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
  };
}

export interface SecurifyReport {
  issues: SecurifyIssue[];
  summary: {
    totalIssues: number;
    criticalCount: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
  };
}

export class AuditService {
  async runComprehensiveAnalysis(contractContent: string, contractPath: string) {
    // Phase 1: Static Analysis Tools
    const [aderynReport, mythxReport, slitherReport, securifyReport] = await Promise.all([
      this.runAderynAnalysis(contractContent),
      this.runMythXAnalysis(contractContent),
      this.runSlitherAnalysis(contractContent, contractPath),
      this.runSecurifyAnalysis(contractContent, contractPath)
    ]);

    // Phase 2: Coverage and Gas Analysis
    const [coverageReport, gasOptimizationReport] = await Promise.all([
      this.runCoverageAnalysis(contractContent, contractPath),
      this.runGasOptimizationAnalysis(contractContent, contractPath)
    ]);

    // Phase 3: Dynamic Testing
    const [fuzzingResults, stressTestResults, attackSimulations] = await Promise.all([
      testingService.runFuzzingTests(contractContent, contractPath),
      testingService.runStressTests(contractContent),
      testingService.runAttackSimulations(contractContent)
    ]);

    return {
      staticAnalysis: {
        aderynReport,
        mythxReport,
        slitherReport,
        securifyReport
      },
      coverageAndOptimization: {
        coverageReport,
        gasOptimizationReport
      },
      dynamicTesting: {
        fuzzingResults,
        stressTestResults,
        attackSimulations
      }
    };
  }
  async runAderynAnalysis(contractContent: string): Promise<AderynReport | null> {
    try {
      // In a real implementation, this would integrate with Aderyn CLI
      // For now, we'll simulate the analysis with environment-based results
      const mockReport: AderynReport = {
        issues: [
          {
            title: "Reentrancy Vulnerability",
            severity: "Critical",
            location: "Line 45-52",
            description: "The contract allows for potential reentrancy attacks in the withdraw function."
          },
          {
            title: "Access Control Issue",
            severity: "High", 
            location: "Line 28-35",
            description: "Missing access control on sensitive functions."
          }
        ],
        summary: {
          totalIssues: 2,
          criticalCount: 1,
          highCount: 1,
          mediumCount: 0,
          lowCount: 0
        }
      };
      
      return mockReport;
    } catch (error) {
      console.error('Aderyn analysis failed:', error);
      return null;
    }
  }

  async runMythXAnalysis(contractContent: string): Promise<MythXReport | null> {
    try {
      const apiKey = process.env.MYTHX_API_KEY || process.env.VITE_MYTHX_API_KEY;
      
      if (!apiKey) {
        console.warn('MythX API key not found, using mock data');
        // Return mock data when API key is not available
        const mockReport: MythXReport = {
          issues: [
            {
              title: "Integer Overflow Potential",
              severity: "Critical",
              description: "Potential integer overflow in arithmetic operations",
              sourceMap: "28:4:52"
            },
            {
              title: "Missing Input Validation",
              severity: "High",
              description: "Function parameters are not properly validated",
              sourceMap: "35:8:45"
            }
          ],
          summary: {
            totalIssues: 2,
            criticalCount: 1,
            highCount: 1,
            mediumCount: 0,
            lowCount: 0
          }
        };
        return mockReport;
      }

      const response = await axios.post(
        'https://api.mythx.io/v1/analyses',
        {
          sources: {
            'contract.sol': {
              source: contractContent
            }
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      // Wait for analysis to complete
      await new Promise(resolve => setTimeout(resolve, 30000));
      
      const report = await axios.get(
        `https://api.mythx.io/v1/analyses/${response.data.uuid}`,
        { headers: { 'Authorization': `Bearer ${apiKey}` } }
      );
      
      return this.parseMythXReport(report.data);
    } catch (error) {
      console.error('MythX analysis failed:', error);
      return null;
    }
  }

  async runSlitherAnalysis(contractContent: string, contractPath: string): Promise<SlitherReport | null> {
    try {
      // Create temporary directory for analysis
      const tempDir = path.join(process.cwd(), 'temp', 'slither');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }

      const contractFile = path.join(tempDir, 'contract.sol');
      fs.writeFileSync(contractFile, contractContent);

      // Mock Slither analysis (in production, would run: slither contract.sol --json)
      const mockReport: SlitherReport = {
        issues: [
          {
            check: 'reentrancy-eth',
            confidence: 'High',
            impact: 'High',
            description: 'Reentrancy in withdraw function allows external calls before state changes',
            elements: [{
              name: 'withdraw',
              source_mapping: {
                start: 450,
                length: 120,
                filename_relative: 'contract.sol',
                lines: [45, 46, 47, 48, 49]
              }
            }]
          },
          {
            check: 'unchecked-call',
            confidence: 'Medium',
            impact: 'High',
            description: 'Call return value not checked',
            elements: [{
              name: 'transfer',
              source_mapping: {
                start: 280,
                length: 65,
                filename_relative: 'contract.sol',
                lines: [28, 29, 30]
              }
            }]
          }
        ],
        summary: {
          totalIssues: 2,
          criticalCount: 0,
          highCount: 2,
          mediumCount: 0,
          lowCount: 0
        }
      };

      return mockReport;
    } catch (error) {
      console.error('Slither analysis failed:', error);
      return null;
    }
  }

  async runSecurifyAnalysis(contractContent: string, contractPath: string): Promise<SecurifyReport | null> {
    try {
      // Mock Securify analysis (in production, would integrate with Securify API/CLI)
      const mockReport: SecurifyReport = {
        issues: [
          {
            severity: 'Critical',
            title: 'Integer Overflow',
            description: 'Potential integer overflow in arithmetic operations without SafeMath',
            line: 42,
            column: 15
          },
          {
            severity: 'High',
            title: 'Unprotected Ether Withdrawal',
            description: 'Function allows withdrawal without proper access control',
            line: 55,
            column: 8
          },
          {
            severity: 'Medium',
            title: 'Missing Event Emission',
            description: 'State-changing function does not emit events',
            line: 38,
            column: 5
          }
        ],
        summary: {
          totalIssues: 3,
          criticalCount: 1,
          highCount: 1,
          mediumCount: 1,
          lowCount: 0
        }
      };

      return mockReport;
    } catch (error) {
      console.error('Securify analysis failed:', error);
      return null;
    }
  }

  async runCoverageAnalysis(contractContent: string, contractPath: string): Promise<CoverageReport> {
    try {
      // Mock unit test coverage analysis (in production, would run with Hardhat/Foundry)
      const mockReport: CoverageReport = {
        totalLines: 150,
        coveredLines: 128,
        coveragePercentage: 85.3,
        uncoveredFunctions: ['emergencyStop', 'recoverFunds', 'upgradeContract'],
        branchCoverage: 78.9
      };

      return mockReport;
    } catch (error) {
      console.error('Coverage analysis failed:', error);
      return {
        totalLines: 0,
        coveredLines: 0,
        coveragePercentage: 0,
        uncoveredFunctions: [],
        branchCoverage: 0
      };
    }
  }

  async runGasOptimizationAnalysis(contractContent: string, contractPath: string): Promise<GasOptimizationReport> {
    try {
      // Mock gas optimization analysis (in production, would use tools like gas-reporter)
      const mockReport: GasOptimizationReport = {
        totalGasUsed: 2_847_293,
        optimizationSuggestions: [
          {
            location: 'Line 25-30: constructor',
            description: 'Use immutable variables for values set once in constructor',
            potentialSaving: 15000,
            severity: 'High'
          },
          {
            location: 'Line 45: withdraw function',
            description: 'Cache array length in loops to avoid repeated SLOAD',
            potentialSaving: 8500,
            severity: 'Medium'
          },
          {
            location: 'Line 62: transfer function',
            description: 'Pack struct variables to reduce storage slots',
            potentialSaving: 12000,
            severity: 'High'
          }
        ],
        expensiveFunctions: [
          {
            name: 'batchTransfer',
            gasUsage: 485_293,
            optimizationHint: 'Consider batching external calls or using assembly'
          },
          {
            name: 'complexCalculation',
            gasUsage: 287_593,
            optimizationHint: 'Pre-calculate constant values off-chain'
          }
        ]
      };

      return mockReport;
    } catch (error) {
      console.error('Gas optimization analysis failed:', error);
      return {
        totalGasUsed: 0,
        optimizationSuggestions: [],
        expensiveFunctions: []
      };
    }
  }

  private parseMythXReport(data: any): MythXReport {
    const issues = data.issues || [];
    const summary = {
      totalIssues: issues.length,
      criticalCount: issues.filter((i: any) => i.severity === 'Critical').length,
      highCount: issues.filter((i: any) => i.severity === 'High').length,
      mediumCount: issues.filter((i: any) => i.severity === 'Medium').length,
      lowCount: issues.filter((i: any) => i.severity === 'Low').length,
    };

    return { issues, summary };
  }
}

export const auditService = new AuditService();

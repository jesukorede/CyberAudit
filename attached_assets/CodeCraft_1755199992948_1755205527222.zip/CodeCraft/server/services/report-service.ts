import type { Audit, Contract, Finding, AuditReport } from "@shared/schema";
import { testingService } from './testing-service';

export interface ReportData {
  audit: Audit;
  contract: Contract;
  findings: Finding[];
  summary: {
    totalFindings: number;
    criticalCount: number;
    highCount: number;
    mediumCount: number;
    lowCount: number;
    infoCount: number;
  };
  testingResults: {
    fuzzing?: any;
    stressTest?: any;
    attackSimulations?: any[];
  };
  executiveSummary: string;
  recommendation: string;
  riskAssessment: string;
  proofsOfConcept: Array<{
    findingId: number;
    title: string;
    exploitCode: string;
    impact: string;
    steps: string[];
  }>;
  remediationPlan: Array<{
    findingId: number;
    priority: 'Immediate' | 'High' | 'Medium' | 'Low';
    guidance: string[];
    estimatedEffort: string;
  }>;
}

export class ReportService {
  generateReportData(
    audit: Audit,
    contract: Contract,
    findings: Finding[]
  ): ReportData {
    const summary = this.calculateSummary(findings);
    const executiveSummary = this.generateExecutiveSummary(summary, audit);
    const recommendation = this.generateRecommendation(summary);
    const riskAssessment = this.generateRiskAssessment(summary, audit);
    const proofsOfConcept = this.generateProofsOfConcept(findings);
    const remediationPlan = this.generateRemediationPlan(findings);

    const testingResults = {
      fuzzing: audit.fuzzingResults,
      stressTest: audit.stressTestResults,
      attackSimulations: audit.attackSimulations
    };

    return {
      audit,
      contract,
      findings,
      summary,
      testingResults,
      executiveSummary,
      recommendation,
      riskAssessment,
      proofsOfConcept,
      remediationPlan
    };
  }

  private calculateSummary(findings: Finding[]) {
    return {
      totalFindings: findings.length,
      criticalCount: findings.filter(f => f.severity === 'Critical').length,
      highCount: findings.filter(f => f.severity === 'High').length,
      mediumCount: findings.filter(f => f.severity === 'Medium').length,
      lowCount: findings.filter(f => f.severity === 'Low').length,
      infoCount: findings.filter(f => f.severity === 'Info').length,
    };
  }

  private generateExecutiveSummary(summary: any, audit: Audit): string {
    let baseSummary = '';
    
    if (summary.criticalCount > 0) {
      baseSummary = `The smart contract audit has identified ${summary.criticalCount} critical security vulnerabilities that require immediate attention. The contract contains issues that could lead to significant financial losses and should not be deployed until all critical findings are resolved.`;
    } else if (summary.highCount > 0) {
      baseSummary = `The smart contract audit has identified ${summary.highCount} high-severity security issues that require attention before deployment. While not immediately critical, these issues pose significant security risks.`;
    } else if (summary.mediumCount > 0) {
      baseSummary = `The smart contract audit has identified ${summary.mediumCount} medium-severity issues that should be addressed to improve the contract's security posture.`;
    } else {
      baseSummary = `The smart contract audit has been completed successfully with no critical or high-severity issues identified. The contract appears to follow security best practices.`;
    }
    
    // Add testing results summary
    const testingSummary = this.generateTestingSummary(audit);
    
    return `${baseSummary} ${testingSummary}`;
  }

  private generateTestingSummary(audit: Audit): string {
    let testingSummary = '';
    
    if (audit.fuzzingResults) {
      const fuzzing = audit.fuzzingResults as any;
      testingSummary += `Fuzzing tests revealed ${fuzzing.testsFailed || 0} failing property tests with ${fuzzing.coverage || 0}% code coverage. `;
    }
    
    if (audit.attackSimulations) {
      const attacks = audit.attackSimulations as any[];
      const successfulAttacks = attacks.filter(a => a.success).length;
      testingSummary += `Attack simulations identified ${successfulAttacks} successful attack vectors out of ${attacks.length} scenarios tested. `;
    }
    
    if (audit.stressTestResults) {
      testingSummary += `Stress testing revealed acceptable performance under load with identified scaling limits. `;
    }
    
    return testingSummary;
  }

  private generateRiskAssessment(summary: any, audit: Audit): string {
    let riskLevel = 'Low';
    let riskFactors = [];

    if (summary.criticalCount > 0) {
      riskLevel = 'Critical';
      riskFactors.push(`${summary.criticalCount} critical vulnerabilities present`);
    } else if (summary.highCount > 0) {
      riskLevel = 'High';
      riskFactors.push(`${summary.highCount} high-severity issues identified`);
    } else if (summary.mediumCount > 0) {
      riskLevel = 'Medium';
      riskFactors.push(`${summary.mediumCount} medium-severity issues present`);
    }

    // Add testing-based risk factors
    if (audit.attackSimulations) {
      const attacks = audit.attackSimulations as any[];
      const successfulAttacks = attacks.filter(a => a.success && a.severity === 'Critical').length;
      if (successfulAttacks > 0) {
        riskFactors.push(`${successfulAttacks} successful critical attack simulations`);
        if (riskLevel === 'Low' || riskLevel === 'Medium') {
          riskLevel = 'High';
        }
      }
    }

    return `Overall Risk Assessment: ${riskLevel}. ${riskFactors.length > 0 ? 'Key risk factors: ' + riskFactors.join(', ') + '.' : 'No significant risk factors identified.'}`;
  }

  private generateProofsOfConcept(findings: Finding[]): Array<{
    findingId: number;
    title: string;
    exploitCode: string;
    impact: string;
    steps: string[];
  }> {
    return findings
      .filter(f => f.severity === 'Critical' || f.severity === 'High')
      .map(finding => {
        const poc = testingService.generateProofOfConcept(finding);
        return {
          findingId: finding.id,
          title: poc.title,
          exploitCode: poc.exploitCode,
          impact: poc.impact,
          steps: poc.reproductionSteps
        };
      });
  }

  private generateRemediationPlan(findings: Finding[]): Array<{
    findingId: number;
    priority: 'Immediate' | 'High' | 'Medium' | 'Low';
    guidance: string[];
    estimatedEffort: string;
  }> {
    return findings.map(finding => {
      const guidance = testingService.generateRemediationGuidance(finding);
      
      let priority: 'Immediate' | 'High' | 'Medium' | 'Low';
      let estimatedEffort: string;
      
      switch (finding.severity) {
        case 'Critical':
          priority = 'Immediate';
          estimatedEffort = '1-3 days';
          break;
        case 'High':
          priority = 'High';
          estimatedEffort = '3-7 days';
          break;
        case 'Medium':
          priority = 'Medium';
          estimatedEffort = '1-2 weeks';
          break;
        case 'Low':
          priority = 'Low';
          estimatedEffort = '2-4 weeks';
          break;
        default:
          priority = 'Low';
          estimatedEffort = '1-2 weeks';
      }

      return {
        findingId: finding.id,
        priority,
        guidance,
        estimatedEffort
      };
    });
  }

  private generateRecommendation(summary: any): string {
    if (summary.criticalCount > 0 || summary.highCount > 0) {
      return `We strongly recommend addressing all critical and high-severity findings before deployment. The contract should undergo another security review after fixes are implemented.`;
    }
    
    if (summary.mediumCount > 0) {
      return `We recommend addressing the medium-severity findings to enhance the contract's security. The contract may proceed to deployment with appropriate risk assessment.`;
    }
    
    return `The contract has passed the security audit and is ready for deployment. We recommend implementing a bug bounty program and continuous monitoring post-deployment.`;
  }

  // This would generate an actual PDF in a real implementation
  async generatePDF(reportData: ReportData): Promise<string> {
    // Mock PDF generation - would use PDFKit or similar library
    const pdfPath = `/reports/audit-${reportData.audit.id}.pdf`;
    console.log(`PDF report generated: ${pdfPath}`);
    return pdfPath;
  }

  // This would generate an actual certificate in a real implementation
  async generateCertificate(reportData: ReportData): Promise<string | null> {
    if (reportData.summary.criticalCount > 0 || reportData.summary.highCount > 0) {
      return null; // No certificate for failed audits
    }
    
    const certificatePath = `/certificates/cert-${reportData.audit.id}.pdf`;
    console.log(`Certificate generated: ${certificatePath}`);
    return certificatePath;
  }
}

export const reportService = new ReportService();

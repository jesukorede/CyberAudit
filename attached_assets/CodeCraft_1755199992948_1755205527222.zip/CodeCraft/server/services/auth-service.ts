import bcrypt from 'bcrypt';
import crypto from 'crypto';
import type { User, InsertUser, LoginInput, Session } from '@shared/schema';

export interface AuthUser {
  id: number;
  email: string;
  username: string;
  firstName?: string;
  lastName?: string;
  role: string;
  status: string;
}

export class AuthService {
  async hashPassword(password: string): Promise<string> {
    const saltRounds = 12;
    return bcrypt.hash(password, saltRounds);
  }

  async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  generateSessionId(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  generateInviteCode(): string {
    return crypto.randomBytes(16).toString('hex').toUpperCase();
  }

  calculateSessionExpiry(): Date {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + 7); // 7 days
    return expiry;
  }

  sanitizeUser(user: User): AuthUser {
    return {
      id: user.id,
      email: user.email,
      username: user.username,
      firstName: user.firstName || undefined,
      lastName: user.lastName || undefined,
      role: user.role,
      status: user.status
    };
  }

  isAuthorized(user: AuthUser, action: string, resource?: any): boolean {
    // Check if user is approved
    if (user.status !== 'approved') {
      return false;
    }

    switch (action) {
      case 'read':
        return ['admin', 'auditor', 'viewer'].includes(user.role);
      
      case 'create_audit':
      case 'update_audit':
      case 'add_finding':
        return ['admin', 'auditor'].includes(user.role);
      
      case 'approve_user':
      case 'manage_invites':
      case 'assign_auditor':
        return user.role === 'admin';
      
      case 'generate_report':
        return ['admin', 'auditor'].includes(user.role);
      
      default:
        return false;
    }
  }

  requireApproval(user: AuthUser): boolean {
    return user.status === 'pending';
  }

  isAdmin(user: AuthUser): boolean {
    return user.role === 'admin' && user.status === 'approved';
  }

  canAccessAudit(user: AuthUser, audit: any): boolean {
    if (!this.isAuthorized(user, 'read')) {
      return false;
    }

    // Admins can access all audits
    if (user.role === 'admin') {
      return true;
    }

    // Users can access audits they created or are assigned to
    return audit.createdBy === user.id || 
           audit.leadAuditor === user.id ||
           audit.assignments?.some((a: any) => a.userId === user.id);
  }
}

export const authService = new AuthService();
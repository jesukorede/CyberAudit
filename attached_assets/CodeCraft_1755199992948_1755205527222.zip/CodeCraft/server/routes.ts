import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { auditService } from "./services/audit-service";
import { reportService } from "./services/report-service";
import { authService, type AuthUser } from "./services/auth-service";
import { insertUserSchema, loginSchema, type InsertUser, type LoginInput } from "@shared/schema";
import { insertContractSchema, insertAuditSchema, insertFindingSchema } from "@shared/schema";

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

// Authentication middleware
async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const sessionId = req.headers.authorization?.replace('Bearer ', '');
  
  if (!sessionId) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const session = await storage.getSession(sessionId);
  if (!session) {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }

  const user = await storage.getUser(session.userId);
  if (!user) {
    return res.status(401).json({ error: 'User not found' });
  }

  const authUser = authService.sanitizeUser(user);
  
  if (authUser.status !== 'approved') {
    return res.status(403).json({ error: 'Account pending approval' });
  }

  req.user = authUser;
  next();
}

// Admin-only middleware
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.user || !authService.isAdmin(req.user)) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// Auditor or Admin middleware
function requireAuditor(req: Request, res: Response, next: NextFunction) {
  if (!req.user || !authService.isAuthorized(req.user, 'create_audit')) {
    return res.status(403).json({ error: 'Auditor access required' });
  }
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ error: 'User already exists' });
      }

      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ error: 'Username already taken' });
      }

      // Validate invite code if provided
      if (userData.inviteCode) {
        const inviteCode = await storage.getInviteCodeByCode(userData.inviteCode);
        if (!inviteCode || !inviteCode.isActive || inviteCode.usedCount >= inviteCode.maxUses) {
          return res.status(400).json({ error: 'Invalid or expired invite code' });
        }
        
        // Update invite code usage
        await storage.updateInviteCode(inviteCode.id, {
          usedCount: inviteCode.usedCount + 1
        });
      }

      // Hash password and create user
      const passwordHash = await authService.hashPassword(userData.password);
      const user = await storage.createUser({
        ...userData,
        passwordHash
      });

      const sanitizedUser = authService.sanitizeUser(user);
      res.status(201).json({ 
        message: 'User created successfully. Awaiting admin approval.',
        user: sanitizedUser 
      });
    } catch (error) {
      res.status(400).json({ error: 'Invalid user data' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(loginData.email);
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const isValidPassword = await authService.verifyPassword(loginData.password, user.passwordHash);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      if (user.status !== 'approved') {
        return res.status(403).json({ error: 'Account pending approval' });
      }

      // Create session
      const sessionId = authService.generateSessionId();
      const expiresAt = authService.calculateSessionExpiry();
      await storage.createSession(sessionId, user.id, expiresAt);

      // Update last login
      await storage.updateUser(user.id, { lastLoginAt: new Date() });

      const sanitizedUser = authService.sanitizeUser(user);
      res.json({ 
        sessionId,
        user: sanitizedUser,
        expiresAt: expiresAt.toISOString()
      });
    } catch (error) {
      res.status(400).json({ error: 'Invalid login data' });
    }
  });

  app.post('/api/auth/logout', requireAuth, async (req, res) => {
    const sessionId = req.headers.authorization?.replace('Bearer ', '');
    if (sessionId) {
      await storage.deleteSession(sessionId);
    }
    res.json({ message: 'Logged out successfully' });
  });

  app.get('/api/auth/me', requireAuth, (req, res) => {
    res.json(req.user);
  });

  // Admin routes
  app.get('/api/admin/users/pending', requireAuth, requireAdmin, async (req, res) => {
    try {
      const pendingUsers = await storage.getPendingUsers();
      const sanitizedUsers = pendingUsers.map(u => authService.sanitizeUser(u));
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch pending users' });
    }
  });

  app.post('/api/admin/users/:id/approve', requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.updateUser(userId, {
        status: 'approved',
        approvedBy: req.user!.id
      });
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json(authService.sanitizeUser(user));
    } catch (error) {
      res.status(500).json({ error: 'Failed to approve user' });
    }
  });

  app.post('/api/admin/users/:id/reject', requireAuth, requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.updateUser(userId, {
        status: 'rejected',
        approvedBy: req.user!.id
      });
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json(authService.sanitizeUser(user));
    } catch (error) {
      res.status(500).json({ error: 'Failed to reject user' });
    }
  });

  app.post('/api/admin/invite-codes', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { maxUses = 1, expiresAt } = req.body;
      const code = authService.generateInviteCode();
      
      const inviteCode = await storage.createInviteCode({
        code,
        createdBy: req.user!.id,
        maxUses,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        isActive: true
      });

      res.json(inviteCode);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create invite code' });
    }
  });

  app.get('/api/admin/users', requireAuth, requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const sanitizedUsers = users.map(u => authService.sanitizeUser(u));
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });

  // Re-audit capability
  app.post('/api/audits/:id/re-audit', requireAuth, requireAuditor, async (req, res) => {
    try {
      const originalAuditId = parseInt(req.params.id);
      const originalAudit = await storage.getAuditWithContract(originalAuditId);
      
      if (!originalAudit) {
        return res.status(404).json({ error: 'Original audit not found' });
      }

      // Create new audit based on the original
      const reAudit = await storage.createAudit({
        contractId: originalAudit.contractId,
        status: 'pending',
        overallProgress: 0,
        leadAuditor: req.user!.id
      }, req.user!.id);

      res.json({
        message: 'Re-audit created successfully',
        originalAuditId,
        newAuditId: reAudit.id,
        audit: reAudit
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create re-audit' });
    }
  });
  // Contract routes (protected)
  app.post('/api/contracts', requireAuth, async (req, res) => {
    try {
      const contractData = insertContractSchema.parse(req.body);
      const contract = await storage.createContract(contractData, req.user!.id);
      res.json(contract);
    } catch (error) {
      res.status(400).json({ error: 'Invalid contract data' });
    }
  });

  app.get('/api/contracts', requireAuth, async (req, res) => {
    try {
      const contracts = req.user!.role === 'admin' 
        ? await storage.getAllContracts()
        : await storage.getContractsByUser(req.user!.id);
      res.json(contracts);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch contracts' });
    }
  });

  app.get('/api/contracts/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const contract = await storage.getContract(id);
      if (!contract) {
        return res.status(404).json({ error: 'Contract not found' });
      }
      
      // Check access permissions
      if (req.user!.role !== 'admin' && contract.uploadedBy !== req.user!.id) {
        return res.status(403).json({ error: 'Access denied' });
      }
      
      res.json(contract);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch contract' });
    }
  });

  // Audit routes (protected)
  app.post('/api/audits', requireAuth, requireAuditor, async (req, res) => {
    try {
      const auditData = insertAuditSchema.parse(req.body);
      const audit = await storage.createAudit(auditData, req.user!.id);
      res.json(audit);
    } catch (error) {
      res.status(400).json({ error: 'Invalid audit data' });
    }
  });

  app.get('/api/audits', requireAuth, async (req, res) => {
    try {
      const audits = req.user!.role === 'admin' 
        ? await storage.getAllAudits()
        : await storage.getAuditsByUser(req.user!.id);
      res.json(audits);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch audits' });
    }
  });

  app.get('/api/audits/:id', requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const audit = await storage.getAuditWithContract(id);
      if (!audit) {
        return res.status(404).json({ error: 'Audit not found' });
      }
      
      // Check access permissions
      if (!authService.canAccessAudit(req.user!, audit)) {
        return res.status(403).json({ error: 'Access denied' });
      }
      
      res.json(audit);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch audit' });
    }
  });

  app.post('/api/audits/:id/start-automated', requireAuth, requireAuditor, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const audit = await storage.getAuditWithContract(id);
      
      if (!audit) {
        return res.status(404).json({ error: 'Audit not found' });
      }

      // Run automated analysis only
      const [aderynReport, mythxReport] = await Promise.all([
        auditService.runAderynAnalysis(audit.contract.content),
        auditService.runMythXAnalysis(audit.contract.content)
      ]);

      // Update audit with results
      const updatedAudit = await storage.updateAudit(id, {
        aderynReport,
        mythxReport,
        status: 'automated',
        overallProgress: 25
      });

      res.json(updatedAudit);
    } catch (error) {
      res.status(500).json({ error: 'Failed to start automated analysis' });
    }
  });

  app.post('/api/audits/:id/start-testing', requireAuth, requireAuditor, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const audit = await storage.getAuditWithContract(id);
      
      if (!audit) {
        return res.status(404).json({ error: 'Audit not found' });
      }

      // Run comprehensive testing
      const contractPath = `/tmp/contract-${id}.sol`;
      const testingResults = await auditService.runComprehensiveAnalysis(
        audit.contract.content, 
        contractPath
      );

      // Update audit with testing results
      const updatedAudit = await storage.updateAudit(id, {
        fuzzingResults: testingResults.fuzzingResults,
        stressTestResults: testingResults.stressTestResults,
        attackSimulations: testingResults.attackSimulations,
        status: 'testing',
        overallProgress: 50
      });

      res.json(updatedAudit);
    } catch (error) {
      res.status(500).json({ error: 'Failed to start testing phase' });
    }
  });

  app.put('/api/audits/:id', requireAuth, requireAuditor, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const audit = await storage.updateAudit(id, updates);
      
      if (!audit) {
        return res.status(404).json({ error: 'Audit not found' });
      }
      
      res.json(audit);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update audit' });
    }
  });

  // Finding routes (protected)
  app.post('/api/findings', requireAuth, requireAuditor, async (req, res) => {
    try {
      const findingData = insertFindingSchema.parse(req.body);
      const finding = await storage.createFinding(findingData, req.user!.id);
      res.json(finding);
    } catch (error) {
      res.status(400).json({ error: 'Invalid finding data' });
    }
  });

  app.get('/api/audits/:id/findings', requireAuth, async (req, res) => {
    try {
      const auditId = parseInt(req.params.id);
      
      // Check if user can access this audit
      const audit = await storage.getAudit(auditId);
      if (!audit || !authService.canAccessAudit(req.user!, audit)) {
        return res.status(403).json({ error: 'Access denied' });
      }
      
      const findings = await storage.getFindingsByAudit(auditId);
      res.json(findings);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch findings' });
    }
  });

  app.delete('/api/findings/:id', requireAuth, requireAuditor, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteFinding(id);
      
      if (!deleted) {
        return res.status(404).json({ error: 'Finding not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete finding' });
    }
  });

  // Report routes (protected)
  app.post('/api/audits/:id/generate-report', requireAuth, requireAuditor, async (req, res) => {
    try {
      const auditId = parseInt(req.params.id);
      const audit = await storage.getAuditWithContract(auditId);
      
      if (!audit) {
        return res.status(404).json({ error: 'Audit not found' });
      }

      const findings = await storage.getFindingsByAudit(auditId);
      const reportData = reportService.generateReportData(audit, audit.contract, findings);
      
      const pdfPath = await reportService.generatePDF(reportData);
      const certificatePath = await reportService.generateCertificate(reportData);
      
      const auditReport = await storage.createAuditReport({
        auditId,
        reportData,
        pdfPath,
        certificatePath
      });

      // Update audit status
      await storage.updateAudit(auditId, {
        status: 'completed',
        overallProgress: 100
      });

      res.json(auditReport);
    } catch (error) {
      res.status(500).json({ error: 'Failed to generate report' });
    }
  });

  app.get('/api/audits/:id/report', async (req, res) => {
    try {
      const auditId = parseInt(req.params.id);
      const report = await storage.getAuditReport(auditId);
      
      if (!report) {
        return res.status(404).json({ error: 'Report not found' });
      }
      
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch report' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { 
  contracts, audits, findings, auditReports, users, sessions, inviteCodes, auditAssignments,
  type Contract, type InsertContract,
  type Audit, type InsertAudit,
  type Finding, type InsertFinding,
  type AuditReport, type InsertAuditReport,
  type User, type InsertUser,
  type Session, type InviteCode, type InsertInviteCode,
  type AuditAssignment
} from "@shared/schema";

export interface IStorage {
  // User methods
  createUser(user: InsertUser & { passwordHash: string }): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUser(id: number): Promise<User | undefined>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  getPendingUsers(): Promise<User[]>;

  // Session methods
  createSession(sessionId: string, userId: number, expiresAt: Date): Promise<Session>;
  getSession(sessionId: string): Promise<Session | undefined>;
  deleteSession(sessionId: string): Promise<boolean>;
  cleanExpiredSessions(): Promise<void>;

  // Invite code methods
  createInviteCode(inviteCode: InsertInviteCode): Promise<InviteCode>;
  getInviteCodeByCode(code: string): Promise<InviteCode | undefined>;
  updateInviteCode(id: number, updates: Partial<InviteCode>): Promise<InviteCode | undefined>;
  getInviteCodesByUser(userId: number): Promise<InviteCode[]>;

  // Contract methods
  createContract(contract: InsertContract, userId: number): Promise<Contract>;
  getContract(id: number): Promise<Contract | undefined>;
  getAllContracts(): Promise<Contract[]>;
  getContractsByUser(userId: number): Promise<Contract[]>;

  // Audit methods
  createAudit(audit: InsertAudit, userId: number): Promise<Audit>;
  getAudit(id: number): Promise<Audit | undefined>;
  getAuditWithContract(id: number): Promise<(Audit & { contract: Contract }) | undefined>;
  updateAudit(id: number, updates: Partial<Audit>): Promise<Audit | undefined>;
  getAuditsByContract(contractId: number): Promise<Audit[]>;
  getAllAudits(): Promise<Audit[]>;
  getAuditsByUser(userId: number): Promise<Audit[]>;

  // Finding methods
  createFinding(finding: InsertFinding, userId: number): Promise<Finding>;
  getFindingsByAudit(auditId: number): Promise<Finding[]>;
  deleteFinding(id: number): Promise<boolean>;
  updateFinding(id: number, updates: Partial<Finding>): Promise<Finding | undefined>;

  // Report methods
  createAuditReport(report: InsertAuditReport): Promise<AuditReport>;
  getAuditReport(auditId: number): Promise<AuditReport | undefined>;

  // Audit assignment methods
  assignUserToAudit(auditId: number, userId: number, role: string): Promise<AuditAssignment>;
  getAuditAssignments(auditId: number): Promise<AuditAssignment[]>;
  removeAuditAssignment(auditId: number, userId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private sessions: Map<string, Session> = new Map();
  private inviteCodes: Map<number, InviteCode> = new Map();
  private auditAssignments: Map<number, AuditAssignment> = new Map();
  private contracts: Map<number, Contract> = new Map();
  private audits: Map<number, Audit> = new Map();
  private findings: Map<number, Finding> = new Map();
  private auditReports: Map<number, AuditReport> = new Map();
  
  private currentUserId = 1;
  private currentInviteCodeId = 1;
  private currentAssignmentId = 1;
  private currentContractId = 1;
  private currentAuditId = 1;
  private currentFindingId = 1;
  private currentReportId = 1;

  constructor() {
    // Create default admin user
    this.createDefaultAdmin();
  }

  private async createDefaultAdmin() {
    const now = new Date();
    const adminUser: User = {
      id: this.currentUserId++,
      email: 'admin@company.com',
      username: 'admin',
      passwordHash: '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewD5bYt2n8Tqbqti', // password: admin123
      firstName: 'System',
      lastName: 'Administrator',
      role: 'admin',
      status: 'approved',
      inviteCode: null,
      approvedBy: null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now
    };
    this.users.set(adminUser.id, adminUser);
  }

  // User methods
  async createUser(userData: InsertUser & { passwordHash: string }): Promise<User> {
    const now = new Date();
    const user: User = {
      id: this.currentUserId++,
      email: userData.email,
      username: userData.username,
      passwordHash: userData.passwordHash,
      firstName: userData.firstName || null,
      lastName: userData.lastName || null,
      role: userData.role || 'viewer',
      status: userData.status || 'pending',
      inviteCode: userData.inviteCode || null,
      approvedBy: userData.approvedBy || null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now
    };
    this.users.set(user.id, user);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      ...updates,
      updatedAt: new Date()
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getPendingUsers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(u => u.status === 'pending');
  }

  // Session methods
  async createSession(sessionId: string, userId: number, expiresAt: Date): Promise<Session> {
    const session: Session = {
      id: sessionId,
      userId,
      expiresAt,
      createdAt: new Date()
    };
    this.sessions.set(sessionId, session);
    return session;
  }

  async getSession(sessionId: string): Promise<Session | undefined> {
    const session = this.sessions.get(sessionId);
    if (session && session.expiresAt < new Date()) {
      this.sessions.delete(sessionId);
      return undefined;
    }
    return session;
  }

  async deleteSession(sessionId: string): Promise<boolean> {
    return this.sessions.delete(sessionId);
  }

  async cleanExpiredSessions(): Promise<void> {
    const now = new Date();
    Array.from(this.sessions.entries()).forEach(([id, session]) => {
      if (session.expiresAt < now) {
        this.sessions.delete(id);
      }
    });
  }

  // Invite code methods
  async createInviteCode(inviteCodeData: InsertInviteCode): Promise<InviteCode> {
    const inviteCode: InviteCode = {
      id: this.currentInviteCodeId++,
      code: inviteCodeData.code,
      createdBy: inviteCodeData.createdBy,
      maxUses: inviteCodeData.maxUses || 1,
      usedCount: 0,
      expiresAt: inviteCodeData.expiresAt || null,
      isActive: inviteCodeData.isActive !== false,
      createdAt: new Date()
    };
    this.inviteCodes.set(inviteCode.id, inviteCode);
    return inviteCode;
  }

  async getInviteCodeByCode(code: string): Promise<InviteCode | undefined> {
    return Array.from(this.inviteCodes.values()).find(ic => ic.code === code);
  }

  async updateInviteCode(id: number, updates: Partial<InviteCode>): Promise<InviteCode | undefined> {
    const inviteCode = this.inviteCodes.get(id);
    if (!inviteCode) return undefined;
    
    const updatedInviteCode = { ...inviteCode, ...updates };
    this.inviteCodes.set(id, updatedInviteCode);
    return updatedInviteCode;
  }

  async getInviteCodesByUser(userId: number): Promise<InviteCode[]> {
    return Array.from(this.inviteCodes.values()).filter(ic => ic.createdBy === userId);
  }

  // Contract methods
  async createContract(insertContract: InsertContract, userId: number): Promise<Contract> {
    const contract: Contract = {
      ...insertContract,
      id: this.currentContractId++,
      language: insertContract.language || 'solidity',
      uploadedBy: userId,
      uploadedAt: new Date(),
    };
    this.contracts.set(contract.id, contract);
    return contract;
  }

  async getContractsByUser(userId: number): Promise<Contract[]> {
    return Array.from(this.contracts.values()).filter(c => c.uploadedBy === userId);
  }

  async getContract(id: number): Promise<Contract | undefined> {
    return this.contracts.get(id);
  }

  async getAllContracts(): Promise<Contract[]> {
    return Array.from(this.contracts.values());
  }

  // Audit methods
  async createAudit(insertAudit: InsertAudit, userId: number): Promise<Audit> {
    const now = new Date();
    const audit: Audit = {
      ...insertAudit,
      id: this.currentAuditId++,
      status: insertAudit.status || 'pending',
      overallProgress: insertAudit.overallProgress || 0,
      createdBy: userId,
      leadAuditor: insertAudit.leadAuditor || null,
      createdAt: now,
      updatedAt: now,
    };
    this.audits.set(audit.id, audit);
    return audit;
  }

  async getAuditsByUser(userId: number): Promise<Audit[]> {
    return Array.from(this.audits.values()).filter(a => 
      a.createdBy === userId || a.leadAuditor === userId
    );
  }

  async getAudit(id: number): Promise<Audit | undefined> {
    return this.audits.get(id);
  }

  async getAuditWithContract(id: number): Promise<(Audit & { contract: Contract }) | undefined> {
    const audit = this.audits.get(id);
    if (!audit) return undefined;
    
    const contract = this.contracts.get(audit.contractId);
    if (!contract) return undefined;
    
    return { ...audit, contract };
  }

  async updateAudit(id: number, updates: Partial<Audit>): Promise<Audit | undefined> {
    const audit = this.audits.get(id);
    if (!audit) return undefined;
    
    const updatedAudit = { ...audit, ...updates, updatedAt: new Date() };
    this.audits.set(id, updatedAudit);
    return updatedAudit;
  }

  async getAuditsByContract(contractId: number): Promise<Audit[]> {
    return Array.from(this.audits.values()).filter(audit => audit.contractId === contractId);
  }

  async getAllAudits(): Promise<Audit[]> {
    return Array.from(this.audits.values());
  }

  // Finding methods
  async createFinding(insertFinding: InsertFinding, userId: number): Promise<Finding> {
    const finding: Finding = {
      ...insertFinding,
      id: this.currentFindingId++,
      source: insertFinding.source || 'manual',
      createdBy: userId,
      reviewedBy: insertFinding.reviewedBy || null,
      status: insertFinding.status || 'open',
      createdAt: new Date(),
    };
    this.findings.set(finding.id, finding);
    return finding;
  }

  async updateFinding(id: number, updates: Partial<Finding>): Promise<Finding | undefined> {
    const finding = this.findings.get(id);
    if (!finding) return undefined;
    
    const updatedFinding = { ...finding, ...updates };
    this.findings.set(id, updatedFinding);
    return updatedFinding;
  }

  // Audit assignment methods
  async assignUserToAudit(auditId: number, userId: number, role: 'lead_auditor' | 'auditor' | 'reviewer'): Promise<AuditAssignment> {
    const assignment: AuditAssignment = {
      id: this.currentAssignmentId++,
      auditId,
      userId,
      role,
      assignedAt: new Date()
    };
    this.auditAssignments.set(assignment.id, assignment);
    return assignment;
  }

  async getAuditAssignments(auditId: number): Promise<AuditAssignment[]> {
    return Array.from(this.auditAssignments.values()).filter(a => a.auditId === auditId);
  }

  async removeAuditAssignment(auditId: number, userId: number): Promise<boolean> {
    for (const [id, assignment] of this.auditAssignments.entries()) {
      if (assignment.auditId === auditId && assignment.userId === userId) {
        this.auditAssignments.delete(id);
        return true;
      }
    }
    return false;
  }

  async getFindingsByAudit(auditId: number): Promise<Finding[]> {
    return Array.from(this.findings.values()).filter(finding => finding.auditId === auditId);
  }

  async deleteFinding(id: number): Promise<boolean> {
    return this.findings.delete(id);
  }

  // Report methods
  async createAuditReport(insertReport: InsertAuditReport): Promise<AuditReport> {
    const report: AuditReport = {
      ...insertReport,
      id: this.currentReportId++,
      generatedAt: new Date(),
    };
    this.auditReports.set(report.id, report);
    return report;
  }

  async getAuditReport(auditId: number): Promise<AuditReport | undefined> {
    return Array.from(this.auditReports.values()).find(report => report.auditId === auditId);
  }
}

export const storage = new MemStorage();

import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User management and authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  role: text("role", { enum: ["admin", "auditor", "viewer"] }).notNull().default("viewer"),
  status: text("status", { enum: ["pending", "approved", "suspended", "rejected"] }).notNull().default("pending"),
  inviteCode: varchar("invite_code", { length: 50 }),
  approvedBy: integer("approved_by").references(() => users.id),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id", { length: 255 }).primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const inviteCodes = pgTable("invite_codes", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  maxUses: integer("max_uses").notNull().default(1),
  usedCount: integer("used_count").notNull().default(0),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const auditAssignments = pgTable("audit_assignments", {
  id: serial("id").primaryKey(),
  auditId: integer("audit_id").notNull().references(() => audits.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role", { enum: ["lead_auditor", "auditor", "reviewer"] }).notNull(),
  assignedAt: timestamp("assigned_at").notNull().defaultNow(),
});

export const contracts = pgTable("contracts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  content: text("content").notNull(),
  language: text("language").notNull().default("solidity"),
  uploadedBy: integer("uploaded_by").notNull().references(() => users.id),
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
});

export const audits = pgTable("audits", {
  id: serial("id").primaryKey(),
  contractId: integer("contract_id").notNull().references(() => contracts.id),
  status: text("status", { 
    enum: ["pending", "automated", "testing", "manual_review", "completed", "failed"] 
  }).notNull().default("pending"),
  aderynReport: jsonb("aderyn_report"),
  mythxReport: jsonb("mythx_report"),
  fuzzingResults: jsonb("fuzzing_results"),
  stressTestResults: jsonb("stress_test_results"),
  attackSimulations: jsonb("attack_simulations"),
  overallProgress: integer("overall_progress").notNull().default(0),
  createdBy: integer("created_by").notNull().references(() => users.id),
  leadAuditor: integer("lead_auditor").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const findings = pgTable("findings", {
  id: serial("id").primaryKey(),
  auditId: integer("audit_id").notNull().references(() => audits.id),
  lineNumber: integer("line_number").notNull(),
  severity: text("severity", { 
    enum: ["Critical", "High", "Medium", "Low", "Info"] 
  }).notNull(),
  type: text("type").notNull(),
  comment: text("comment").notNull(),
  source: text("source", { enum: ["manual", "aderyn", "mythx", "fuzzing", "stress_test", "attack_sim"] }).notNull().default("manual"),
  proofOfConcept: text("proof_of_concept"),
  remediationGuidance: text("remediation_guidance"),
  impact: text("impact"),
  exploitPath: jsonb("exploit_path"),
  createdBy: integer("created_by").notNull().references(() => users.id),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  status: text("status", { enum: ["open", "confirmed", "false_positive", "resolved"] }).notNull().default("open"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const auditReports = pgTable("audit_reports", {
  id: serial("id").primaryKey(),
  auditId: integer("audit_id").notNull().references(() => audits.id),
  reportData: jsonb("report_data").notNull(),
  pdfPath: text("pdf_path"),
  certificatePath: text("certificate_path"),
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastLoginAt: true,
}).extend({
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, "Password is required"),
});

export const inviteCodeSchema = createInsertSchema(inviteCodes).omit({
  id: true,
  createdAt: true,
  usedCount: true,
});

export const insertContractSchema = createInsertSchema(contracts).omit({
  id: true,
  uploadedAt: true,
  uploadedBy: true,
});

export const insertAuditSchema = createInsertSchema(audits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  createdBy: true,
});

export const insertFindingSchema = createInsertSchema(findings).omit({
  id: true,
  createdAt: true,
  createdBy: true,
});

export const insertAuditReportSchema = createInsertSchema(auditReports).omit({
  id: true,
  generatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type Session = typeof sessions.$inferSelect;
export type InviteCode = typeof inviteCodes.$inferSelect;
export type InsertInviteCode = z.infer<typeof inviteCodeSchema>;
export type AuditAssignment = typeof auditAssignments.$inferSelect;
export type Contract = typeof contracts.$inferSelect;
export type InsertContract = z.infer<typeof insertContractSchema>;
export type Audit = typeof audits.$inferSelect;
export type InsertAudit = z.infer<typeof insertAuditSchema>;
export type Finding = typeof findings.$inferSelect;
export type InsertFinding = z.infer<typeof insertFindingSchema>;
export type AuditReport = typeof auditReports.$inferSelect;
export type InsertAuditReport = z.infer<typeof insertAuditReportSchema>;
